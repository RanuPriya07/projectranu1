#run a python file from another python file
#here fileA.py executes another python file name fileB.py

import fileB

fileB.my_function("Emil", "Refsnes")
