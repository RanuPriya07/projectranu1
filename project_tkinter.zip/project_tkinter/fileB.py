def my_function(fname, lname):
  print(fname + " " + lname)

 
