from tkinter import *
#this tk is a function (display a blank box)
ranu =Tk()#provide basic gui
#width x height (this function is use to determine height nd width of box)
ranu.geometry("400x300")

#width,height
ranu.minsize(200,100)#minimum size of box
ranu.maxsize(600,500)#maximum size of box

#to print in box
golu=Label(text="this is my GUI line 1")#label is a function
golu.pack()#after pack function we can see the above statement in box
sonu=Label(text="this is my GUI line 2")#label is a function
sonu.pack()#after pack function we can see the above statement in box


ranu.mainloop()#provide basic gui
