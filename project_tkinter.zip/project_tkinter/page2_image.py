from tkinter import *
#from PIL import ImageTk, Image

root = Tk()
root.geometry("800x400")

#for jpg image
#photo=Image.open("img1.jpg")
#img=ImageTk.PhotoImage(photo)

img = PhotoImage(file="img2.png")
panel = Label(image = img)
panel.pack()
root.mainloop()
