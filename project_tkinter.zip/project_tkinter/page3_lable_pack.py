from tkinter import *
root = Tk()
root.geometry("444x233")
root.title("My GUI Page")

#important lable options
#text =add the text
#bd =background
#fg =foreground
#font = set the font
#1. font=("comicsansns",19, "bold")
#2. font="comicsansns 19 bold")
#padx = x padding
#pady =y padding
#relief =border styling=SUNKEN, RAISED, GROOVE, RIDGE

a=Label(text='''gfv jhgvuyf uhgiuyg \n ughygf hguyfuy ugyfyt \n uguyft fytft ooihgdxx sesthguy hgyu6ytfrytd ghyfytdstr \n fdcrdtr'''
        ,bg="red", fg="white", padx=112, pady=115, font="comicsansns 19 bold",
        borderwidth=15,relief=SUNKEN)

# important Pack options
# anchor = ne ,nw, se, sw (put the box in desire direction)
# side = top, bottom, left, right (put the box in desire direction)
# fill =x (fill entire row(x) or column(y)
# padx =x axis padding 
# pady= y axis padding

#a.pack(side=TOP, anchor="ne" ,fill="x")
a.pack(side=LEFT, padx=30,pady=5 ,fill="y")
root.mainloop()
