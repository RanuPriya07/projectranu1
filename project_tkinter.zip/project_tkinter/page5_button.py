from tkinter import *

root=Tk()
root.geometry("500x200")

def hello():
    print("Hello tkinter buttons")
    
#frame inside root
f1=Frame(root, borderwidth=6, bg="yellow", relief=SUNKEN)
f1.pack(side=LEFT, anchor="nw" )
#button inside frame
b1=Button(f1, fg="red", text="Submit", command=hello)
b1.pack(side=LEFT)
b2=Button(f1, fg="red", text="Submit")
b2.pack(side=LEFT)
b3=Button(f1, fg="red", text="Submit")
b3.pack(side=BOTTOM)
b4=Button(f1, fg="red", text="Submit")
b4.pack(side=BOTTOM)

root.mainloop()
