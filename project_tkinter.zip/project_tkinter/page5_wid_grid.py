from tkinter import *
#instead of pack use grid

def getval():
    #f stands for format in python version 3.8
    print(f"user name is {uservalue.get()}")
    print(f"password is {passvalue.get()}")

root=Tk()
root.geometry("800x600")

user= Label(root , text="Username")
password= Label(root , text="Password")
user.grid(row=0)
password.grid(row=1)

#variable class in tkinter-BooleanVar, IntVar, StringVar, DoubleVar
#defining type of value we will accept from user
uservalue = StringVar()
passvalue = StringVar()

userentry =Entry(root, textvariable = uservalue)
passentry =Entry(root, textvariable = passvalue)

userentry.grid(row=0, column=1)
passentry.grid(row=1, column=1)

#checkbox

#Button(text="Submit",command=getval).grid()
#OR
a=Button(text="Submit",command=getval)
a.grid()

root.mainloop()
